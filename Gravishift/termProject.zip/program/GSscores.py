#michael Choquette
#These programs manage the player's completed levels and scores

def setProScores(canvas): #setting my best scores
    proScores={}
    proScores[1]=1
    proScores[2]=1
    proScores[3]=1
    proScores[4]=2
    proScores[5]=2
    proScores[6]=2
    proScores[7]=3
    proScores[8]=2
    proScores[9]=4
    proScores[10]=3
    proScores[11]=4
    proScores[12]=4
    canvas.data["proScores"]=proScores

def loadHighScores(canvas): #reads the player's scores into a dictionary.
    highScores={}
    levels=canvas.data["levels"]
    try:
        fileHandler=open("GravishiftHighScores.txt","rt")
        scores=fileHandler.readlines()
        fileHandler.close()
    except:
        scores=["9"]*levels
    for i in xrange(levels):
        highScores[i+1]=int(scores[i])
    canvas.data["highScores"]=highScores

def saveHighScores(canvas): #saves a dictionary of player's scores into a file.
    levels=canvas.data["levels"]
    highScores=canvas.data["highScores"]
    string=str(highScores[1])
    for i in xrange(2,levels+1):
        string+="\n"+str(highScores[i])
    fileHandler=open("GravishiftHighScores.txt","wt")
    fileHandler.write(string)
    fileHandler.close()

#checks if a score is better than the last high score, and stors it if it is.
def checkScore(canvas): 
    level=canvas.data["level"]
    highScores=canvas.data["highScores"]
    #modifying the relevant score if it's better than the high score
    highScores[level]=min(highScores[level],canvas.data["score"])
    canvas.data["highScores"]=highScores
    saveHighScores(canvas)
