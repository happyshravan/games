Michael Choquette, mchoquet

The game Gravishift is a physics-based puzzle game that runs in python on a computer.

In order to run the game Gravishift, you must have python installed on your computer,
and the following files in a common folder:
	Gravishift.py
	GSclasses.py
	GSlevels.py
	GSscores.py
TO run the game, double-click on the program Gravishift.py.
If this does not work, open the program in a python interpreter (like IDLE),
and run it from there.